#!/usr/bin/env python3
import os
import sys
import subprocess
import time
import requests
import json
import signal

# ─── ZynChat Remote Server Controller ──────────────────────────────────────────
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(SCRIPT_DIR)

# --- CONFIGURATION (Set these in your environment or here) ---
RENDER_API_KEY = os.getenv("RENDER_API_KEY", "rnd_66AXn28xtvkp3bTTiCwu6gqL1ei9")
SERVICE_ID     = os.getenv("RENDER_SERVICE_ID", "srv-d8146rr7uimc7381bbo0")
# --------------------------------------------------------------

C_BLU = "\033[94m"
C_CYN = "\033[96m"
C_GRN = "\033[92m"
C_YLW = "\033[93m"
C_RED = "\033[91m"
C_RST = "\033[0m"
C_BOLD = "\033[1m"

def update_render_env(enabled):
    if RENDER_API_KEY == "your_render_api_key_here":
        print(f"{C_RED}[!] Error: Render API Key not set in launch.py{C_RST}")
        return

    val = "true" if enabled else "false"
    print(f"{C_YLW}[*] Updating Render Environment: SW_ENABLED={val}...{C_RST}")
    
    headers = {
        "Authorization": f"Bearer {RENDER_API_KEY}",
        "Content-Type": "application/json"
    }
    
    # Render API expects a list of env vars to update/patch
    url = f"https://api.render.com/v1/services/{SERVICE_ID}/env-vars"
    data = [{"key": "SW_ENABLED", "value": val}]
    
    try:
        # Note: Render usually uses a PUT or PATCH for env vars
        response = requests.put(url, headers=headers, json=data)
        if response.status_code in [200, 201, 202]:
            print(f"{C_GRN}[+] Render updated successfully!{C_RST}")
            # Now trigger a cache-cleared redeploy
            clear_cache_and_redeploy()
        else:
            print(f"{C_RED}[-] Render API Error: {response.status_code} - {response.text}{C_RST}")
    except Exception as e:
        print(f"{C_RED}[-] Connection failed: {e}{C_RST}")

def update_render_env_var(key, value):
    if RENDER_API_KEY == "your_render_api_key_here":
        return False

    print(f"{C_YLW}[*] Syncing Render Config: {key}={value}...{C_RST}")
    
    headers = {
        "Authorization": f"Bearer {RENDER_API_KEY}",
        "Content-Type": "application/json"
    }
    
    url = f"https://api.render.com/v1/services/{SERVICE_ID}/env-vars"
    # Note: We use PUT which replaces the whole list or PATCH? 
    # Render API PATCH /env-vars actually updates/adds. 
    # Let's use the same logic as before but for dynamic key.
    data = [{"key": key, "value": value}]
    
    try:
        response = requests.put(url, headers=headers, json=data)
        return response.status_code in [200, 201, 202]
    except:
        return False

def get_ngrok_url():
    try:
        # Check if ngrok is already running and get URL from its API
        res = requests.get("http://localhost:4040/api/tunnels", timeout=2)
        if res.status_code == 200:
            tunnels = res.json().get("tunnels", [])
            for t in tunnels:
                if t.get("proto") == "https":
                    return t.get("public_url")
    except:
        pass
    return None

def start_ngrok_tunnel():
    print(f"{C_YLW}[*] Starting automated ngrok tunnel on port 3002...{C_RST}")
    
    # Try to kill existing ngrok
    subprocess.run("pkill -f ngrok", shell=True, stderr=subprocess.DEVNULL)
    time.sleep(1)
    
    # Start ngrok in background
    # We use -log=stdout to suppress terminal takeover or just redirect
    proc = subprocess.Popen(["ngrok", "http", "3002"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    
    # Wait for tunnel to come up
    for _ in range(10):
        time.sleep(1.5)
        url = get_ngrok_url()
        if url:
            # Strip https://
            clean_url = url.replace("https://", "").replace("http://", "")
            print(f"{C_GRN}[+] Tunnel Active: {url}{C_RST}")
            return clean_url, proc
    
    print(f"{C_RED}[-] Failed to start ngrok. Please start it manually.{C_RST}")
    return None, None

def clear_cache_and_redeploy():
    if RENDER_API_KEY == "your_render_api_key_here":
        print(f"{C_RED}[!] Error: Render API Key not set in launch.py{C_RST}")
        return

    print(f"{C_YLW}[*] Triggering Redeploy with Clear Cache on Render...{C_RST}")
    
    headers = {
        "Authorization": f"Bearer {RENDER_API_KEY}",
        "Content-Type": "application/json",
        "Accept": "application/json"
    }
    
    url = f"https://api.render.com/v1/services/{SERVICE_ID}/deploys"
    data = {"clearCache": "clear"}
    
    try:
        response = requests.post(url, headers=headers, json=data)
        if response.status_code in [200, 201]:
            print(f"{C_GRN}[+] Redeploy triggered successfully! Cache is being cleared.{C_RST}")
        else:
            print(f"{C_RED}[-] Render API Error: {response.status_code} - {response.text}{C_RST}")
    except Exception as e:
        print(f"{C_RED}[-] Connection failed: {e}{C_RST}")

def check_dependencies():
    if not os.path.exists("node_modules"):
        print(f"{C_YLW}[*] Missing dependencies. Installing now...{C_RST}")
        subprocess.run(["npm", "install"], check=True)
    else:
        print(f"{C_GRN}[+] Dependencies verified.{C_RST}")

def launch_local_dashboard():
    check_dependencies()
    print(f"\n{C_BLU}{C_BOLD}🛡️  STARTING AUTOMATED DASHBOARD...{C_RST}")
    
    # 1. Start Tunnel
    addr, ngrok_proc = start_ngrok_tunnel()
    
    if addr:
        # 2. Update Render
        success = update_render_env_var("SW_CEREBRO_ADDR", addr)
        if success:
            print(f"{C_GRN}[+] Render updated with new tunnel address.{C_RST}")
            print(f"{C_YLW}[*] Triggering redeploy to apply new address...{C_RST}")
            clear_cache_and_redeploy()
        else:
            print(f"{C_RED}[-] Failed to update Render environment.{C_RST}")
    
    # Kill previous dashboard
    subprocess.run("fuser -k 3002/tcp 2>/dev/null", shell=True)
    
    print("-" * 60)
    print(f"{C_GRN}[*] Dashboard: http://localhost:3002{C_RST}")
    print(f"{C_CYN}[*] Login: shieldwatch-admin-2024{C_RST}")
    print(f"{C_BLU}[*] Monitoring: {addr if addr else 'Local Only'}{C_RST}")
    print("-" * 60)
    
    try:
        # Run collector
        collector_proc = subprocess.Popen(["node", "shieldwatch/collector.js"])
        
        print(f"\n{C_BOLD}🚀 System is LIVE. Press Ctrl+C to stop everything.{C_RST}")
        
        while True:
            time.sleep(1)
            if collector_proc.poll() is not None:
                break
    except KeyboardInterrupt:
        print(f"\n{C_YLW}[*] Shutting down tunnel and dashboard...{C_RST}")
        if ngrok_proc: ngrok_proc.terminate()
        collector_proc.terminate()
        subprocess.run("pkill -f ngrok", shell=True)

if __name__ == "__main__":
    os.system('clear' if os.name == 'posix' else 'cls')
    print(f"{C_BLU}{C_BOLD}=================================================={C_RST}")
    print(f"{C_CYN}{C_BOLD}          ZYNCHAT REMOTE SERVER CONTROLLER        {C_RST}")
    print(f"{C_BLU}{C_BOLD}=================================================={C_RST}")
    print(f"{C_GRN}1.{C_RST} {C_BOLD}ENABLE{C_RST} ShieldWatch Protection (on Render)")
    print(f"{C_RED}2.{C_RST} {C_BOLD}DISABLE{C_RST} ShieldWatch Protection (on Render)")
    print(f"{C_CYN}3.{C_RST} {C_BOLD}LAUNCH{C_RST} Local Dashboard (Monitor Render)")
    print(f"{C_YLW}4.{C_RST} {C_BOLD}CLEAR CACHE{C_RST} and Redeploy (on Render)")
    print(f"{C_RED}5.{C_RST} {C_BOLD}EXIT{C_RST}")
    print(f"{C_BLU}=================================================={C_RST}")
    
    choice = input(f"{C_BOLD}Action [1-5]: {C_RST}").strip()
    
    if choice == "1":
        update_render_env(True)
    elif choice == "2":
        update_render_env(False)
    elif choice == "3":
        launch_local_dashboard()
    elif choice == "4":
        clear_cache_and_redeploy()
    elif choice == "5":
        sys.exit(0)
    else:
        print(f"{C_RED}[!] Invalid choice.{C_RST}")
