/**
 * ShieldWatch RASP Sensor — ZynChat Integration v2
 * ─────────────────────────────────────────────────────────────────────────────
 * Environment variables:
 *
 *   SW_ENABLED=true
 *   SW_CEREBRO_ADDR=abc123.ngrok-free.app     ← ngrok HTTP tunnel (no port)
 *                OR localhost:3002             ← local testing
 *   SW_APP_ID=zynchat
 *   SW_LOG_ONLY=false   (true = detect but never block — passive mode)
 *
 * ─────────────────────────────────────────────────────────────────────────────
 */

const http   = require('http');
const https  = require('https');
const crypto = require('crypto');

const RAW_ADDR  = process.env.SW_CEREBRO_ADDR || 'localhost:3002';
const APP_ID    = process.env.SW_APP_ID       || 'zynchat';
const LOG_ONLY  = process.env.SW_LOG_ONLY === 'true';
const API_TOKEN = process.env.SW_API_TOKEN || 'sw-internal-token-xyz';

// ─── Shared Helpers ──────────────────────────────────────────────────────────
// ─── IP Extraction (Standardized for ngrok/proxies) ───────────────────────────
function extractIP(req) {
  let ip = req.headers['x-forwarded-for'] || req.socket?.remoteAddress || req.connection?.remoteAddress || '127.0.0.1';
  if (ip.includes(',')) ip = ip.split(',')[0];
  return ip.trim().replace(/^::ffff:/, '').replace(/^::1$/, '127.0.0.1');
}

// ─── Block Enforcement Middleware ─────────────────────────────────────────────
function checkBlocking(req, res) {
  const ip = extractIP(req);
  const fp = req.session?.fpId;
  const sid = req.session?.username || req.session?.sessionKey || req.sessionID;

  // 1. IP Block - DISABLED by request (to prevent network collateral)
  /*
  if (blockedIPs.has(ip)) {
    return true;
  }
  */

  // 2. Check Device Fingerprint Block (Global for device)
  if (fp && blockedFingerprints.has(fp)) {
    console.log(`[ShieldWatch] ⛔ Blocked Device attempt: ${fp}`);
    return true;
  }

  // 3. Check Session Block (Surgical - This is what you want for demo!)
  if (sid && blockedSessions.has(sid)) {
    console.log(`[ShieldWatch] ⛔ Blocked Session attempt: ${sid}`);
    return true;
  }

  return false;
}

// ─── Main HTTP Middleware ─────────────────────────────────────────────────────
// (Removed duplicate)

const MAX_TRACKER_SIZE = 10_000;

// ─── Parse the collector address ──────────────────────────────────────────────
// Supports:
//   localhost:3002          → http, port 3002
//   abc123.ngrok-free.app  → https, port 443  (ngrok HTTP tunnel)
//   0.tcp.ngrok.io:12345   → http, port 12345 (ngrok TCP tunnel)
function parseAddr(addr) {
  // Clean up: remove protocol, trailing slashes, and whitespace
  let clean = addr.trim().replace(/^https?:\/\//, '').replace(/\/+$/, '');
  
  if (clean.includes(':')) {
    const [host, portStr] = clean.split(':');
    const port = parseInt(portStr, 10);
    return { host, port: isNaN(port) ? 3002 : port, useHttps: false };
  }
  // No port = ngrok HTTPS domain (default to 443)
  return { host: clean, port: 443, useHttps: true };
}

const COLLECTOR = parseAddr(RAW_ADDR);

// ─── IP Blocklist (synced from ShieldWatch collector every 30s) ──────────────
const blockedIPs = new Set();

function fetchBlocklist() {
  const module_ = COLLECTOR.useHttps ? https : http;
  const options  = {
    hostname: COLLECTOR.host,
    port:     COLLECTOR.port,
    path:     '/api/blocked',
    method:   'GET',
    headers:  { 
      'ngrok-skip-browser-warning': 'true',
      'x-shieldwatch-token': API_TOKEN
    },
    timeout:  4000,
  };
  const req = module_.request(options, res => {
    let data = '';
    res.on('data', c => data += c);
    res.on('end', () => {
      try {
        if (res.statusCode !== 200) return;
        const list = JSON.parse(data);
        if (Array.isArray(list)) {
           blockedIPs.clear();
           list.forEach(ip => blockedIPs.add(ip));
           if (list.length > 0) {
             console.log(`[ShieldWatch] 🚫 IP blocklist synced: ${list.length} IPs`);
             if (global.onShieldWatchBlock) global.onShieldWatchBlock(); // Trigger instant kick
           }
        }
      } catch (e) {
        console.error("[ShieldWatch] ⚠️ IP sync error:", e.message);
      }
    });
  });
  req.on('error',   () => {});
  req.on('timeout', () => req.destroy());
  req.end();
}

// Sync IP blocklist immediately + every 3 seconds for instant demo blocking
fetchBlocklist();
setInterval(fetchBlocklist, 3000);

// ─── Fingerprint Blocklist (synced from collector every 30s) ─────────────────
const blockedFingerprints = new Set();

function fetchFingerprintBlocklist() {
  const module_ = COLLECTOR.useHttps ? https : http;
  const options  = {
    hostname: COLLECTOR.host,
    port:     COLLECTOR.port,
    path:     '/api/blocked-fp',
    method:   'GET',
    headers:  { 
      'ngrok-skip-browser-warning': 'true',
      'x-shieldwatch-token': API_TOKEN
    },
    timeout:  4000,
  };
  const req = module_.request(options, res => {
    let data = '';
    res.on('data', c => data += c);
    res.on('end', () => {
      try {
        if (res.statusCode !== 200) {
           // If dashboard says no, we don't assume everyone is unblocked
           // but we log the error to debug why sync is failing
           return;
        }
        const list = JSON.parse(data);
        if (Array.isArray(list)) {
          blockedFingerprints.clear();
          list.forEach(fp => blockedFingerprints.add(fp));
          if (list.length > 0) {
            console.log(`[ShieldWatch] 🔒 Fingerprint blocklist synced: ${list.length} hashes`);
            if (global.onShieldWatchBlock) global.onShieldWatchBlock();
          }
        }
      } catch (e) {
        console.error("[ShieldWatch] ⚠️ Fingerprint sync error:", e.message);
      }
    });
  });
  req.on('error',   () => {});
  req.on('timeout', () => req.destroy());
  req.end();
}

fetchFingerprintBlocklist();
setInterval(fetchFingerprintBlocklist, 3000);

// ─── Session Blocklist (synced from collector every 3s) ──────────────────────
const blockedSessions = new Set();

function fetchSessionBlocklist() {
  const module_ = COLLECTOR.useHttps ? https : http;
  const options  = {
    hostname: COLLECTOR.host,
    port:     COLLECTOR.port,
    path:     '/api/blocked-sessions',
    method:   'GET',
    headers:  { 
      'ngrok-skip-browser-warning': 'true',
      'x-shieldwatch-token': API_TOKEN
    },
    timeout:  4000,
  };
  const req = module_.request(options, res => {
    let data = '';
    res.on('data', c => data += c);
    res.on('end', () => {
      try {
        const list = JSON.parse(data);
        blockedSessions.clear();
        list.forEach(s => blockedSessions.add(s));
        if (list.length > 0) {
          console.log(`[ShieldWatch] ✂️ Session blocklist synced: ${list.length} IDs`);
          if (global.onShieldWatchBlock) global.onShieldWatchBlock();
        }
      } catch {}
    });
  });
  req.on('error', () => {});
  req.on('timeout', () => req.destroy());
  req.end();
}

fetchSessionBlocklist();
setInterval(fetchSessionBlocklist, 3000);

// ─── IDOR Detection ──────────────────────────────────────────────────────────
function checkIDOR(req) {
  const rawPath = (req.path || req.url || '/').split('?')[0];
  // /api/user/:id — accessing another user's full record
  const match = rawPath.match(/^\/api\/user\/(\d+)$/);
  if (!match) return null;
  const requestedId  = parseInt(match[1], 10);
  const sessionUserId = req.session?.userId;
  // Accessing ANY user record without owning it = IDOR
  if (!sessionUserId || requestedId !== sessionUserId) {
    return {
      type:    'idor',
      matched: 'Shield (App): Unauthorized object access (IDOR)',
      raw:     `GET /api/user/${requestedId} — session belongs to user:${sessionUserId || 'anonymous'}`,
    };
  }
  return null;
}

// ─── Session Fixation Detection ───────────────────────────────────────────────
const SESSION_FIXATION_PATHS = new Map([
  ['/api/session/id',  'session ID exposure endpoint accessed'],
  ['/api/session/fix', 'session fixation attack — forced session ID injection'],
]);

function checkSessionFixation(req) {
  const rawPath = (req.path || req.url || '/').split('?')[0];
  const desc = SESSION_FIXATION_PATHS.get(rawPath);
  if (!desc) return null;
  return {
    type:    'sessionFixation',
    matched: desc,
    raw:     `${req.method} ${rawPath} from ${req.session?.username || 'anonymous'}`,
  };
}

// ─── CSRF Detection ──────────────────────────────────────────────────────────
// State-changing endpoints that must only be called via JSON (not form POST)
const CSRF_PROTECTED = new Set(['/api/profile/update', '/api/settings', '/api/user/delete']);

function checkCSRF(req) {
  const rawPath = (req.path || req.url || '/').split('?')[0];
  if (!CSRF_PROTECTED.has(rawPath)) return null;
  if (!['POST', 'PUT', 'DELETE', 'PATCH'].includes(req.method)) return null;

  const ct = (req.headers['content-type'] || '').toLowerCase();
  // Legitimate app calls always use application/json
  // A CSRF form submission arrives as application/x-www-form-urlencoded or multipart
  if (ct.includes('application/x-www-form-urlencoded') || ct.includes('multipart/form-data')) {
    const origin  = req.headers['origin']  || '';
    const referer = req.headers['referer'] || '';
    return {
      type:    'csrf',
      matched: 'Shield (App): Unauthorized state-changing form submission (CSRF)',
      raw:     `${req.method} ${rawPath} | Origin: ${origin || 'none'} | Referer: ${referer || 'none'}`,
    };
  }
  return null;
}

// ─── Brute Force Detection ────────────────────────────────────────────────────
const loginFailTracker = new Map(); // ip → [timestamp, ...]
const BF_WINDOW_MS = 60_000;        // 60-second window
const BF_THRESHOLD = 5;             // ≥ 5 failures in 60s = brute force

function trackLoginFailure(req) {
  const ip  = extractIP(req);
  const now = Date.now();
  const prev = (loginFailTracker.get(ip) || []).filter(t => now - t < BF_WINDOW_MS);
  prev.push(now);

  if (loginFailTracker.size >= MAX_TRACKER_SIZE && !loginFailTracker.has(ip)) {
    loginFailTracker.delete(loginFailTracker.keys().next().value);
  }
  loginFailTracker.set(ip, prev);

  if (prev.length >= BF_THRESHOLD) {
    const threat  = {
      type:    'bruteforce',
      matched: 'Shield (App): Login Brute Force detected',
      raw:     `${prev.length} failed login attempts from ${ip}`,
    };
    const verdict = LOG_ONLY ? 'LOGGED' : 'BLOCKED';
    const event   = buildEvent(req, threat, verdict);
    console.log(`[ShieldWatch] 🔐 BRUTE FORCE | ${ip} | ${prev.length} failures | ${verdict}`);
    report('/api/event', event);
    return verdict === 'BLOCKED'; // true = caller should return 429
  }
  return false;
}

// ─── DDoS / Rate-Limit Detection ─────────────────────────────────────────────
const requestTracker = new Map();   // ip → [timestamp, ...]
const DDOS_WINDOW_MS = 10_000;      // 10-second sliding window
const DDOS_THRESHOLD = 20;          // > 20 API requests in 10s = flood

function checkDDoS(ip) {
  const now  = Date.now();
  const prev = (requestTracker.get(ip) || []).filter(t => now - t < DDOS_WINDOW_MS);
  prev.push(now);

  if (requestTracker.size >= MAX_TRACKER_SIZE && !requestTracker.has(ip)) {
    requestTracker.delete(requestTracker.keys().next().value);
  }
  requestTracker.set(ip, prev);
  if (prev.length > DDOS_THRESHOLD) {
    return {
      type:    'ddos',
      matched: 'Shield (App): API Request Flood detected',
      raw:     `${prev.length} requests in 10s from ${ip}`,
    };
  }
  return null;
}

// Purge stale entries every 30 seconds to avoid memory growth
setInterval(() => {
  const cutoff = Date.now() - DDOS_WINDOW_MS;
  for (const [ip, times] of requestTracker) {
    const fresh = times.filter(t => t > cutoff);
    if (fresh.length === 0) requestTracker.delete(ip);
    else requestTracker.set(ip, fresh);
  }
}, 30_000);

// ─── Honeypot paths ──────────────────────────────────────────────────────────
const HONEYPOT_PATHS = new Set([
  '/api/admin/users', '/api/admin/config', '/api/export',
  '/api/export/database', '/api/backup', '/api/db-dump',
  '/api/config', '/api/secret', '/admin', '/phpmyadmin',
  '/wp-admin', '/.env',
]);

// ─── Attack Patterns ─────────────────────────────────────────────────────────
const PATTERNS = {
  sqli: [
    /'\s*(--|#|\/\*)/i,
    /'\s*(OR|AND)\s+['"\d]/i,
    /\bunion\b.+\bselect\b/i,
    /\bselect\b.+\bfrom\b/i,
    /\bdrop\s+table\b/i,
    /\binsert\s+into\b/i,
    /'\s*=\s*'/i,
    /;\s*(DROP|ALTER|CREATE|INSERT|UPDATE|DELETE)\b/i,
    /\bsleep\s*\(/i,
    /\bwaitfor\s+delay\b/i,
  ],
  xss: [
    /<script[\s>]/i,
    /javascript\s*:/i,
    /on\w+\s*=\s*['"`]/i,
    /<img[^>]+onerror/i,
    /<iframe[\s>]/i,
    /\balert\s*\(/i,
    /document\.cookie/i,
    /eval\s*\(/i,
    /<svg[^>]+on\w+/i,
    /srcdoc\s*=/i,
    /data\s*:\s*text\/html/i,
    /expression\s*\(/i,
    /vbscript\s*:/i,
    /<base[^>]+href/i,
    /&#x?[0-9a-f]+;/i,
  ],
  pathTraversal: [
    /\.\.\//,
    /\.\.\\/,
    /%2e%2e%2f/i,
    /%2e%2e\//i,
    /\.\.%2f/i,
    /%252e%252e/i,
    /\/etc\/passwd/i,
    /\/proc\/self/i,
  ],
  cmdInjection: [
    /[;&|`$]\s*(ls|cat|pwd|id|whoami|uname|curl|wget|bash|sh|python|perl)\b/i,
    /`[^`]+`/,
    /\$\([^)]+\)/,
  ],
};

// ─── Detect threat ────────────────────────────────────────────────────────────
function detectThreats(value) {
  if (value == null || typeof value !== 'string') return null;
  let decoded = value;
  try { decoded = decodeURIComponent(value); } catch {}

  for (const [type, patterns] of Object.entries(PATTERNS)) {
    for (const re of patterns) {
      if (re.test(value) || re.test(decoded)) {
        const typeMap = { sqli: 'SQL Injection', xss: 'XSS Attempt', pathTraversal: 'Path Traversal', cmdInjection: 'Command Injection' };
        return { type, matched: `Shield (App): ${typeMap[type] || type} signature detected`, raw: value.slice(0, 200) };
      }
    }
  }
  return null;
}

// ─── Scan request inputs ──────────────────────────────────────────────────────
function scanRequest(req) {
  const sensitiveKeys = ['password', 'pass', 'pwd', 'secret', 'token', 'apiKey', 'credential'];
  
  // Scan query params
  if (req.query && Object.keys(req.query).length > 0) {
    console.log(`[ShieldWatch] Scanning query:`, JSON.stringify(req.query));
    for (const [key, val] of Object.entries(req.query)) {
      if (typeof val !== 'string') continue;
      const t = detectThreats(val);
      if (t) return t;
    }
  }

  // Scan body (with masking for sensitive fields)
  for (const [key, val] of Object.entries(req.body || {})) {
    if (typeof val !== 'string') continue;
    const t = detectThreats(val);
    if (t) {
      const lowerKey = key.toLowerCase();
      if (sensitiveKeys.some(sk => lowerKey.includes(sk))) {
        t.raw = '[REDACTED]'; // Hide the actual password/token
      }
      return t;
    }
  }

  // Scan URL params
  for (const [key, val] of Object.entries(req.params || {})) {
    if (typeof val !== 'string') continue;
    const t = detectThreats(val);
    if (t) return t;
  }
  
  return null;
}

// ─── Send to ShieldWatch Collector ───────────────────────────────────────────
// Non-blocking, fail-open — if ShieldWatch is down ZynChat keeps running
function report(endpoint, payload) {
  const body    = JSON.stringify(payload);
  const module_ = COLLECTOR.useHttps ? https : http;

  const options = {
    hostname: COLLECTOR.host,
    port:     COLLECTOR.port,
    path:     endpoint,
    method:   'POST',
    headers:  {
      'Content-Type':   'application/json',
      'Content-Length': Buffer.byteLength(body),
      'ngrok-skip-browser-warning': 'true',
      'x-shieldwatch-token': API_TOKEN
    },
    timeout: 4000,
  };

  console.log(`[ShieldWatch] 📡 Reporting to ${options.hostname}:${options.port}${options.path}`);

  const req = module_.request(options, res => { 
    if (res.statusCode !== 200) {
      console.error(`[ShieldWatch] ❌ Report failed: ${res.statusCode} to ${endpoint}`);
    }
    res.resume(); 
  });
  req.on('error',   (e) => {
    console.error(`[ShieldWatch] ❌ Report error: ${e.message}`);
  }); 
  req.on('timeout', () => req.destroy());
  req.write(body);
  req.end();
}

// ─── Build event ──────────────────────────────────────────────────────────────
function buildEvent(req, threat, verdict) {
  return {
    id:        crypto.randomUUID(),
    app:       APP_ID,
    timestamp: new Date().toISOString(),
    ip:        extractIP(req),
    method:    req.method,
    path:      req.path || req.url || '/',
    ua:        req.headers['user-agent'] || '',
    threat,
    verdict,
    session:   req.session?.username || 'anonymous',
  };
}

// ─── HTTP Middleware ───────────────────────────────────────────────────────────
function httpMiddleware(req, res, next) {
  const rawPath = (req.path || req.url || '/').split('?')[0];

  // 1. MANDATORY BLOCK CHECK (Instant Rejection)
  if (checkBlocking(req, res)) {
    const ip = extractIP(req);
    return res.status(403).send(`
      <div style="background:#0f172a;color:#f87171;height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;font-family:sans-serif;text-align:center;padding:20px;">
        <h1 style="font-size:80px;margin:0">🚫</h1>
        <h2 style="margin:20px 0;letter-spacing:2px;color:#fff;">ACCESS DENIED</h2>
        <p style="color:#94a3b8;max-width:500px;line-height:1.6">This session has been permanently blacklisted by ShieldWatch. IP or Device Signature has been flagged for malicious activity.</p>
        <div style="margin-top:30px;padding:15px 30px;background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.3);border-radius:12px;font-family:monospace;color:#ef4444">
          BLOCKED_ID: ${ip}
        </div>
        <p style="margin-top:40px;font-size:12px;color:#475569">ShieldWatch RASP Protection Active</p>
      </div>
    `);
  }

  // IDOR check
  const idorThreat = checkIDOR(req);
  if (idorThreat) {
    const verdict = LOG_ONLY ? 'LOGGED' : 'BLOCKED';
    const event   = buildEvent(req, idorThreat, verdict);
    console.log(`[ShieldWatch] 🔓 IDOR | ${rawPath} | ${verdict}`);
    report('/api/event', event);
    if (!LOG_ONLY) {
      return res.status(403).json({
        ok: false, blocked: true,
        error:  'Access denied. IDOR attack blocked by ShieldWatch.',
        threat: 'idor',
        ref:    event.id,
      });
    }
  }

  // Session Fixation check
  const sfThreat = checkSessionFixation(req);
  if (sfThreat) {
    const verdict = LOG_ONLY ? 'LOGGED' : 'BLOCKED';
    const event   = buildEvent(req, sfThreat, verdict);
    console.log(`[ShieldWatch] 🔑 SESSION FIXATION | ${rawPath} | ${verdict}`);
    report('/api/event', event);
    if (!LOG_ONLY) {
      return res.status(403).json({
        ok: false, blocked: true,
        error:  'Session fixation attack blocked by ShieldWatch.',
        threat: 'sessionFixation',
        ref:    event.id,
      });
    }
  }

  // CSRF check (form-encoded POST to protected endpoints)
  const csrfThreat = checkCSRF(req);
  if (csrfThreat) {
    const verdict = LOG_ONLY ? 'LOGGED' : 'BLOCKED';
    const event   = buildEvent(req, csrfThreat, verdict);
    console.log(`[ShieldWatch] 🎭 CSRF | ${req.method} ${rawPath} | ${verdict}`);
    report('/api/event', event);
    if (!LOG_ONLY) {
      return res.status(403).json({
        ok: false, blocked: true,
        error:  'CSRF attack detected and blocked by ShieldWatch.',
        threat: 'csrf',
        ref:    event.id,
      });
    }
  }

  // DDoS rate-limit check (API endpoints only — skip static files)
  if (rawPath.startsWith('/api/') || rawPath.startsWith('/socket')) {
    const ip    = extractIP(req);
    const flood = checkDDoS(ip);
    if (flood) {
      const verdict = LOG_ONLY ? 'LOGGED' : 'BLOCKED';
      const event   = buildEvent(req, flood, verdict);
      console.log(`[ShieldWatch] 🌊 DDOS | ${ip} | ${flood.raw} | ${verdict}`);
      report('/api/event', event);
      if (!LOG_ONLY) {
        return res.status(429).json({
          ok: false, blocked: true,
          error:  'Too many requests. DDoS flood detected by ShieldWatch.',
          threat: 'ddos',
          ref:    event.id,
        });
      }
    }
  }

  // Honeypot check
  if (HONEYPOT_PATHS.has(rawPath)) {
    const event = buildEvent(req, { type: 'honeypot', raw: rawPath }, 'DECOY');
    console.log(`[ShieldWatch] 🍯 HONEYPOT: ${rawPath} | user:${event.session} | ip:${event.ip}`);
    report('/api/event', event);
    req._swHoneypot = true;
    return next(); // Let honeypot handler serve fake data
  }

  const threat = scanRequest(req);
  if (!threat) return next();

  const verdict = LOG_ONLY ? 'LOGGED' : 'BLOCKED';
  const event   = buildEvent(req, threat, verdict);

  console.log(`[ShieldWatch] 🚨 ${threat.type.toUpperCase()} | ${req.method} ${rawPath} | ${verdict} | user:${event.session} | ip:${event.ip}`);
  report('/api/event', event);

  if (LOG_ONLY) return next();

  return res.status(403).json({
    ok: false, blocked: true,
    error:  'Request blocked by ShieldWatch RASP.',
    threat: threat.type,
    ref:    event.id,
  });
}

// ─── Socket.io Message Hook ───────────────────────────────────────────────────
function inspectMessage(msg, socket) {
  const threat = detectThreats(msg.text);
  if (!threat) return;

  const event = {
    id:        crypto.randomUUID(),
    app:       APP_ID,
    timestamp: new Date().toISOString(),
    ip:        socket.handshake?.address || '127.0.0.1',
    method:    'WS',
    path:      '/socket/chat_message',
    ua:        socket.handshake?.headers?.['user-agent'] || '',
    threat,
    verdict:   LOG_ONLY ? 'LOGGED' : 'BLOCKED',
    session:   msg.username || 'unknown',
  };

  console.log(`[ShieldWatch] 🚨 WS ${threat.type.toUpperCase()} from ${msg.username}`);
  report('/api/event', event);
}

function maskPayload(body) {
  if (!body || typeof body !== 'object') return body;
  const masked = { ...body };
  const sensitiveKeys = ['password', 'pass', 'pwd', 'secret', 'token', 'apiKey', 'credential'];
  
  for (const key of Object.keys(masked)) {
    const lowerKey = key.toLowerCase();
    if (sensitiveKeys.some(sk => lowerKey.includes(sk))) {
      masked[key] = '[REDACTED]';
    }
  }
  return masked;
}

// ─── Fingerprint Forwarding ───────────────────────────────────────────────────
function submitFingerprint(fingerprintData, req) {
  const ip      = extractIP(req);
  const session = req.session?.username || 'anonymous';
  report('/api/fingerprint', { session, ip, fingerprint: fingerprintData });
}

// ─── Sync Active Users ────────────────────────────────────────────────────────
function syncActiveUsers(sessions) {
  // sessions should be an array of strings (usernames)
  if (!Array.isArray(sessions)) return;
  report('/api/active-users', { sessions });
}

// ─── Honeypot Hit (manual) ────────────────────────────────────────────────────
function honeypotHit(path, req) {
  const event = buildEvent(req, { type: 'honeypot', raw: path }, 'DECOY');
  console.log(`[ShieldWatch] 🍯 Manual honeypot: ${path}`);
  report('/api/event', event);
}

// ─── Nginx Block Forwarder ───────────────────────────────────────────────────
function reportNginxEvent(req, reason) {
  const threatType = (reason === 'rate-limit') ? 'ddos' : 'bot';
  const threatDesc = (reason === 'rate-limit') ? 'Shield (Network): Rate limit exceeded' : 'Shield (Network): Malicious bot signature';
  
  const event = buildEvent(req, { 
    type:    threatType, 
    matched: threatDesc,
    raw:     req.headers['user-agent'] || 'none'
  }, 'BLOCKED');

  console.log(`[ShieldWatch] 🛡️ Forwarding Network Shield event`);
  report('/api/event', event);
}

module.exports = { 
  httpMiddleware, 
  middleware: httpMiddleware, 
  checkBlocking, // [NEW] Exporting for socket-level blocking
  inspectMessage, 
  detectThreats, 
  submitFingerprint, 
  honeypotHit, 
  trackLoginFailure, 
  reportNginxEvent, 
  syncActiveUsers 
};
